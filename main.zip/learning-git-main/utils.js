// TODO: Implement utils
